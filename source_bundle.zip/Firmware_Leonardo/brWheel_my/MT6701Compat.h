#ifndef MT6701_COMPAT_H
#define MT6701_COMPAT_H

#include <Arduino.h>
#include <Wire.h>

// Compatibility wrapper: exposes the subset of AS5600L API used by brWheel,
// but reads the MT6701 14-bit absolute angle over I2C.
// MT6701 default I2C address: 0x06; angle registers: 0x03 (MSB), 0x04 (LSB[7:2]).
class AS5600L {
public:
  explicit AS5600L(uint8_t address = 0x06) : _address(address) {}

  bool begin() {
    Wire.setClock(400000UL);
    uint16_t raw;
    bool ok = readRaw(raw);
    if (ok) {
      _lastRaw = raw;
      _accum = 0;
      _zeroOffset = 0;
      _initialized = true;
    }
    return ok;
  }

  void setFastFilter(uint8_t) {}
  void setSlowFilter(uint8_t) {}

  int32_t resetCumulativePosition(int32_t newPosition = 0) {
    uint16_t raw;
    if (readRaw(raw)) {
      _lastRaw = raw;
      _accum = 0;
      _zeroOffset = newPosition;
      _initialized = true;
    }
    return newPosition;
  }

  int32_t getCumulativePosition() {
    uint16_t raw;
    if (!readRaw(raw)) return _zeroOffset + _accum;

    if (!_initialized) {
      _lastRaw = raw;
      _initialized = true;
      return _zeroOffset;
    }

    int16_t delta = (int16_t)raw - (int16_t)_lastRaw;
    // Resolve 0/16383 wrap. Valid for < 180 degrees between samples,
    // which is far above any realistic steering-wheel speed at 500 Hz.
    if (delta > 8192) delta -= 16384;
    else if (delta < -8192) delta += 16384;

    _accum += delta;
    _lastRaw = raw;
    return _zeroOffset + _accum;
  }

private:
  bool readRaw(uint16_t &value) {
    Wire.beginTransmission(_address);
    Wire.write((uint8_t)0x03);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom((int)_address, 2) != 2) return false;
    uint8_t msb = Wire.read();
    uint8_t lsb = Wire.read();
    value = ((uint16_t)msb << 6) | ((uint16_t)(lsb & 0xFC) >> 2);
    return true;
  }

  uint8_t _address;
  uint16_t _lastRaw = 0;
  int32_t _accum = 0;
  int32_t _zeroOffset = 0;
  bool _initialized = false;
};

#endif
