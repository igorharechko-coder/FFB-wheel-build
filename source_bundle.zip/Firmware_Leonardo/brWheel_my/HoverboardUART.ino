// UART bridge from Arduino Leonardo FFB torque to EFeru hoverboard-firmware-hack-FOC.
// Leonardo Serial1 pins: D0/RX, D1/TX.
// Use the hoverboard USART3/right sensor cable for the Leonardo TX connection.

#ifdef USE_HOVERBOARD_UART

#define HOVERBOARD_UART_BAUD 115200UL
#define HOVERBOARD_START_FRAME 0xABCDu
#define HOVERBOARD_CMD_MAX 1000
#define HOVERBOARD_DEADBAND 0
#define HOVERBOARD_TORQUE_SCALE_PCT 100

struct HoverboardSerialCommand {
  uint16_t start;
  int16_t steer;
  int16_t speed;
  uint16_t checksum;
} __attribute__((packed));

static HoverboardSerialCommand hoverCmd;

void HoverboardSerialBegin() {
  Serial1.begin(HOVERBOARD_UART_BAUD);
}

static void HoverboardSend(int16_t steer, int16_t speed) {
  hoverCmd.start = HOVERBOARD_START_FRAME;
  hoverCmd.steer = steer;
  hoverCmd.speed = speed;
  hoverCmd.checksum = (uint16_t)(hoverCmd.start ^ (uint16_t)hoverCmd.steer ^ (uint16_t)hoverCmd.speed);
  Serial1.write((const uint8_t *)&hoverCmd, sizeof(hoverCmd));
}

void HoverboardSendTorque(int32_t torque) {
  int32_t denom = MM_MAX_MOTOR_TORQUE;
  if (denom <= 0) denom = 2047;
  int32_t cmd = (torque * HOVERBOARD_CMD_MAX) / denom;
  cmd = (cmd * HOVERBOARD_TORQUE_SCALE_PCT) / 100;
  cmd = constrain(cmd, -HOVERBOARD_CMD_MAX, HOVERBOARD_CMD_MAX);
  if (abs(cmd) <= HOVERBOARD_DEADBAND) cmd = 0;

  // GD32 package uses normal mixer with STEER_COEFFICIENT=0 and SPEED_COEFFICIENT=1.0.
  // Therefore SPEED carries the torque command. Only MOTOR_RIGHT_ENA is enabled.
  HoverboardSend(0, (int16_t)cmd);
}

#endif
